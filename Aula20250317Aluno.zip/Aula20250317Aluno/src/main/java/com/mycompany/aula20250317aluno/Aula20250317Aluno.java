package com.mycompany.aula20250317aluno;

public class Aula20250317Aluno {

    public static void main(String[] args) {
        
        
        System.out.println("ALUNO");
     
        Aluno a1 = new Aluno("Cassio", "CC", "B", 3, 7,8);
        
        
        System.out.println(a1);
        a1.passar("C", 7);

    }
}
